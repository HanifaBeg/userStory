var express = require('express');
const fs = require('fs');
const readline = require('readline');
var router = express.Router();
var split = require('split')
router.route('/').get(getRoute)

function getRoute(req, res) {
	const readInterface = readline.createInterface({
		input: fs.createReadStream('./input_user_story_1.txt')
			//, output: process.stdout
			
		, console: false
	});
	var count = 0;
	var arr1 = [];
	var arr2 = [];
	var arr3 = [];
	readInterface.on('line', function (line) {
		//count++;
		for (var i = 0; i < line.length; i++) {
			if (i % 4 != 0 && count == 0) {
				arr1[i] = line[i];
			}
			if (i % 4 != 0 && count == 1) {
				arr2[i] = line[i];
				count++;
			}
			if (i % 4 != 0 && count == 2) {
				arr3[i] = line[i];
				count++;
			}
			if (count >= 3) {
				count = 0;
			}
		}
		var digits = {
			"0": " _ | ||_|"
			, "1": "     |  |"
			, "2": " _  _||_ "
			, "3": " _  _| _|"
			, "4 ": "   |_|  |"
			, "5": " _ |_  _|"
			, 6: " _ |_ |_|"
			, 7: " _   |  |"
			, " 8": " _ |_||_|"
			, "9": " _ |_|  |"
			, "9": " _ |_| _|"
		, };
		//var digits = JSON.parse(JSON.stringify(digits));
		for (var i = 0; i < 28; i++) {
			//console.log([...arr1[i], ...arr2[i], ...arr3[i]].join(''));
			console.log(arr1[i]);
		}
		for (var key in digits) {}
	});
}
module.exports = router;