const {
	Writeable, Readable
} = require('stream');
var express = require('express');
var router = express.Router();
router.route('/').get(getRouteHandler)

function getRouteHandler(req, res) {
	const rs = new Readable({
		read() {
			for (let i = 1; i < 1000000; i++) {
				if (i % 28 == 0) {
					this.push("MP,");
					continue;
				}
				if (i % 4 == 0) {
					this.push("M,");
					continue;
				}
				if (i % 7 == 0) {
					this.push("P,");
					continue;
				}
				this.push(i + ",");
				//this.push("\r");
			}
			this.push(null);
		}
	});
	rs.pipe(res)
		
	rs.on('end', () => {
		res.end();
	});
}
module.exports = router;