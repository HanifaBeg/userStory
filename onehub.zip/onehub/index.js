var express = require('express');
var router = express.Router();
const app = express()
const port = 2000
app.use('/Marcopolo', require('./routes/Marcopolo'));
app.use('/userStory', require('./routes/userStory'));
app.listen(port, () => console.log(`Example app listening on port ${port}!`))